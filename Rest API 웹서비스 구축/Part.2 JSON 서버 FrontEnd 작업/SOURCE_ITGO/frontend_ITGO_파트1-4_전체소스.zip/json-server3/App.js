/*
	- 디렉토리 : /frontend/json-server3/App.js
	- 주요내용 : REST API 웹 서비스 JSON Server 구축 - App 메인 코드 작성하여 JSON 서버 테스트
				npm install json-server --save

				[ ★ JSON Server 구축하여 프런트엔드 작업하기 ]
*/
// 모듈 삽입 및 서버 객체 생성
const jsonServer = require( 'json-server' );
const app = jsonServer.create();

// [1] path.join 사용
// const path = require( 'path' );
// const router = jsonServer.router( path.join( __dirname, './db/db.json' ) );

// [2] path.join 사용없이 그냥 라우터 설정
const router = jsonServer.router( './db/db.json' );

const middlewares = jsonServer.defaults();
const port = 3000;


// 기본 미들웨어 설정
app.use( middlewares );
app.use( '/favicon.ico', ( req, res ) => res.status(204) );


// To handle POST, PUT, PATCH
app.use( jsonServer.bodyParser );
app.use( router );


// 라우터 설정 - Main
// app.get( '/', ( req, res ) => {
// 	res.send( '<h1>JSON Server .. ♥♥♥♥♥</h1>' );
// } );


// 클라이언트 요청 수신 대기
app.listen( port, ( err ) => {
	if (err) throw err;

	console.log( `JSON Server Running at ${ port } Port from /frontend/json-server3/App.js ~~ ★` );
} );